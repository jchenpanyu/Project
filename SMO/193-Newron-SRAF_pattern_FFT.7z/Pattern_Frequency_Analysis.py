# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 10:40:44 2018

分析pattern的频域特性

@author: vincchen
"""

import os
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt

def PGM5toARRAY(input_pgm, normalization=True):
    pgm_image = Image.open(input_pgm) # 读取PGM
    pgm_array = np.array(pgm_image, np.float32) # convert pgm to array
    pgm_array = pgm_array[::-1] # 读入的pgm上下是颠倒的，所以反序一下
    if normalization:
        pgm_array = (pgm_array - pgm_array.min()) / (pgm_array.max() - pgm_array.min()) # 归一化到0-1
    return pgm_array

pgm_path = r"C:\Users\vincchen\Documents\1_Assignment\193-Newron-SRAF_pattern_FFT\pgm" # 文件所在路径
files_list = os.listdir(pgm_path) # 得到文件夹下所有的文件

file_name_list = []
for f in files_list:
    if os.path.splitext(f)[1] == '.pgm': # 判断是否为PGM文件
         file_name_list.append(f) # 把文件保存到file_name_list
file_name_list.sort()

num_pgm = len(file_name_list)
fig_1 = plt.figure(figsize=(3*num_pgm, 4))
for i in range(num_pgm):
    temp_f = os.path.join(pgm_path, file_name_list[i])
    temp_img = PGM5toARRAY(temp_f)
    ax = fig_1.add_subplot(2, num_pgm, i+1)
    ax.imshow(temp_img, cmap='gray') # 先画上full GDS image
    ax.set_title(os.path.splitext(file_name_list[i])[0])
    # 对原图进行FFT
    temp_img_fft = np.fft.fft2(temp_img)
    temp_img_fft = np.fft.fftshift(temp_img_fft)
    temp_img_fft = np.log(np.abs(temp_img_fft))
    ax = fig_1.add_subplot(2, num_pgm, i+1+num_pgm)
    ax.imshow(temp_img_fft, cmap='gray') # 先画上full GDS image


    
DEFAULT_IMAGE = r"C:\Users\vincchen\Documents\1_Assignment\184-Newron_UMC-L14\data\c0displaymi.pgm"  
img = PGM5toARRAY(DEFAULT_IMAGE)
img_crop = img[0:255, 0:255]
fig_2 = plt.figure()
ax = fig_2.add_subplot(121)
ax.imshow(img_crop, cmap='gray') # 先画上full GDS image
temp_img_fft = np.fft.fft2(img_crop)
temp_img_fft = np.fft.fftshift(temp_img_fft)
temp_img_fft = np.log(np.abs(temp_img_fft))
ax = fig_2.add_subplot(122)
ax.imshow(temp_img_fft, cmap='gray') # 先画上full GDS image



test_1 = os.path.join(pgm_path, file_name_list[2])
test_2 = os.path.join(pgm_path, file_name_list[3])
test_img = PGM5toARRAY(test_1)
test_img[:,256:] = PGM5toARRAY(test_2)[:,256:]
fig = plt.figure()
ax = fig.add_subplot(121)
ax.imshow(test_img, cmap='gray') # 先画上full GDS image
# 对原图进行FFT
temp_img_fft = np.fft.fft2(test_img)
temp_img_fft = np.fft.fftshift(temp_img_fft)
temp_img_fft = np.log(np.abs(temp_img_fft))
ax = fig.add_subplot(122)
ax.imshow(temp_img_fft, cmap='gray') # 先画上full GDS image



