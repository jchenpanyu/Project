"""
===========================================================
Via K-means method to cluster the PGM of different
===========================================================

"""

from PIL import Image
import numpy as np
import os
import matplotlib.pyplot as plt

# Conver the PGM to 1D numpy-array 
def pgm2array(pgm, PGM_max = 65535, PGM_min = 0):
    pgm_array = Image.open(pgm) # read PGM
    pgm_array = np.array(pgm_array) # covert to arrya
    pgm_array = pgm_array.astype(np.float64)
    pgm_array = (pgm_array - PGM_min)/(PGM_max - PGM_min) # normalize to [0,1]
    pgm_array = pgm_array.flatten() # flatten the array into 1D shape
    return pgm_array

## store all the PGM to array
def appenedPGMtoDataset(path, n_pgm=41, prefix = 'c', suffix = 'displaymi.pgm'):
    dataset = None
    for i in np.arange(n_pgm):
         pgm = os.path.join(path, prefix + str(i) + suffix)
         pgm_array = pgm2array(pgm)
         if dataset is None:
             dataset = pgm_array
         else:
             dataset = np.row_stack((dataset, pgm_array))
    return dataset
        
# set pgm store path
pgm_path = r"C:\Users\vincchen\Documents\1_Assignment\172-ML Pattern Selection via Clusting\optimize99result1\\"

# read all the pgm, then convert into num-arrary and store in dataset
dataset = appenedPGMtoDataset(pgm_path)

# clustering the pgm of different design via K-means
from sklearn.cluster import KMeans
number_clusters = 5
km = KMeans(n_clusters=number_clusters,
            init='k-means++',
            n_init=10,
            max_iter=300000,
            tol=1e-04,
            random_state=0)

# predict the clustering results
y_km = km.fit_predict(dataset)
print y_km

# plot the figure of the same class
subfigure_w = 4
subfigure_h = 4
subfigure_perRow = 6
for i in np.arange(number_clusters):
    index_list = np.where(y_km==i)[0]
    nSample_class = len(index_list)
    subfigure_perColunm = np.ceil(np.float16(nSample_class)/subfigure_perRow)
    plt.figure(figsize=(subfigure_w * subfigure_perRow, subfigure_h * subfigure_perColunm))
    for n_plot, index in enumerate(index_list):
        plt.subplot(subfigure_perColunm, subfigure_perRow, n_plot+1)
        plt.imshow(dataset[index].reshape((256, 256)), cmap='gray')
    plt.tight_layout()
    plt.show()





















